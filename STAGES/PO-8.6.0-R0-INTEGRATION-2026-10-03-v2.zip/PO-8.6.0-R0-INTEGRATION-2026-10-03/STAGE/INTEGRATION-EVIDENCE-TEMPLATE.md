# R0 integration evidence
Provider:
Exact use case:
Test destination:
Authorization method:
Requested scopes:
Build fingerprint:
API request performed:
Returned resource/object ID:
HTTP/result status:
Observed quota/rate behavior:
Observed 401/403/429/5xx handling:
Screenshots/video:
Operator notes:

Acceptance: one real owner-controlled provider operation succeeds end-to-end with live automation OFF.
