# R0 — Integration build

Self-contained Platform Orchestrator 8.6.0 stage archive.

- Full source program, including the macOS app: PROGRAM/PLATFORM-ORCHESTRATOR-8.6.0/
- Convenience macOS app copy: APP/Platform Orchestrator.app/
- Stage passport: STAGE/R0-INTEGRATION.md
- Stage manifest: STAGE/STAGE-MANIFEST.yaml
- Provider binding template: STAGE/PROVIDER-BINDING-TEMPLATE.yaml
- Stage evidence/correction/canary template: STAGE/INTEGRATION-EVIDENCE-TEMPLATE.md

All user state, credentials, tokens and live production data are excluded.
