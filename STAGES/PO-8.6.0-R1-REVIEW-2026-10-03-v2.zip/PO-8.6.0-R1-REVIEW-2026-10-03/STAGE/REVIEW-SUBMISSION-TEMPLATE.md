# R1 review submission record
Provider:
Requested product/capability:
Requested scopes (minimum only):
App/client ID:
Redirect URIs:
Test destination:
Privacy URL:
Support URL:
Demo URL:
Build fingerprint:
Successful API resource/object ID:
Reviewer test account/instructions:
Known limitations stated to reviewer:

Checklist:
- [ ] OAuth is real and reproducible.
- [ ] Unrelated providers/capabilities are disabled in the submitted configuration.
- [ ] Every requested scope is demonstrated.
- [ ] No password/cookie/session-token workaround is used.
- [ ] Demo shows the real provider result.
- [ ] No secrets appear in the recording.
