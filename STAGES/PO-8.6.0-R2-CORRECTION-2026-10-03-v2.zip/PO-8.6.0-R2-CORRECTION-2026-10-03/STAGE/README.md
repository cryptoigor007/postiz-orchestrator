# R2 — Post-rejection correction build

Self-contained Platform Orchestrator 8.6.0 stage archive.

- Full source program, including the macOS app: PROGRAM/PLATFORM-ORCHESTRATOR-8.6.0/
- Convenience macOS app copy: APP/Platform Orchestrator.app/
- Stage passport: STAGE/R2-CORRECTION.md
- Stage manifest: STAGE/STAGE-MANIFEST.yaml
- Provider binding template: STAGE/PROVIDER-BINDING-TEMPLATE.yaml
- Stage evidence/correction/canary template: STAGE/REJECTION-CORRECTION-TEMPLATE.md

All user state, credentials, tokens and live production data are excluded.
