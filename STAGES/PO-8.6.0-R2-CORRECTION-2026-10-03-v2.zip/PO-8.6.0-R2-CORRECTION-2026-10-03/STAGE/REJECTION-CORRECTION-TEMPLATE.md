# R2 rejection/correction record
Provider:
R1 build fingerprint:
Review request/rejection ID:
Exact reviewer text:
Blocker class (identity/policy/scope/demo/test access/technical/product eligibility):
Root cause:
Files/config changed:
New requested scopes:
New build fingerprint:
New demo URL:
Resubmission mechanism required by provider:

Constraint: change only the stated blocker first. Do not broaden permissions or add unrelated functionality.
