from __future__ import annotations

import logging
import os
import shutil
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path

from .config import AppConfig
from .db import Database

logger = logging.getLogger(__name__)


def run_backup(db: Database, cfg: AppConfig, backup_dir: str | Path) -> Path | None:
    if not cfg.backup.enabled:
        return None
    backup_dir = Path(backup_dir)
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
        # проверяем, что путь реально доступен на запись (иначе — откат к папке рядом с БД)
        if not os.access(backup_dir, os.W_OK):
            raise PermissionError(str(backup_dir))
    except OSError:
        alt = Path(db.path).resolve().parent / "backups"
        try:
            alt.mkdir(parents=True, exist_ok=True)
            if not os.access(alt, os.W_OK):
                raise PermissionError(str(alt))
            logger.warning("Backup dir %s недоступен — использую %s", backup_dir, alt)
            backup_dir = alt
        except OSError:
            logger.warning("Backup пропущен: нет доступной папки для %s", db.path)
            return None
    ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    dest = backup_dir.resolve() / f"data_{ts}.sqlite"
    # 10.1: use sqlite3 backup API (no SQL string with path)
    try:
        dest_s = str(dest)
        if any(c in dest_s for c in ("\x00", "\n", "\r")):
            raise ValueError(f"unsafe backup path: {dest_s!r}")
        with closing(sqlite3.connect(db.path)) as src:
            with closing(sqlite3.connect(dest_s)) as dst:
                src.backup(dst)
        logger.info("Backup created: %s", dest)
        mirror = os.getenv("ORCH_BACKUP_MIRROR", "").strip()
        if mirror:
            try:
                mdir = Path(mirror)
                mdir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, mdir / dest.name)
                _cleanup(mdir, cfg.backup.keep_days)
                logger.info("Backup mirrored: %s", mdir / dest.name)
            except Exception:
                logger.exception("Backup mirror failed")
        _cleanup(backup_dir, cfg.backup.keep_days)
        # гигиена журнала: старые записи publish_log не нужны
        try:
            with closing(sqlite3.connect(db.path)) as c:
                with c:
                    cur = c.execute(
                        "DELETE FROM publish_log WHERE created_at < datetime('now', '-90 day')")
                    if cur.rowcount:
                        logger.info("publish_log pruned: %s rows", cur.rowcount)
        except Exception:
            logger.exception("publish_log prune failed")
        return dest
    except Exception as e:
        logger.error("Backup failed: %s", e)
        return None


#: Что подпадает под ретенцию keep_days. Кроме регулярных data_YYYYMMDD_HHMMSS.sqlite
#: в ту же папку пишутся «именованные» снимки (ручные копии перед правками и миграциями) —
#: раньше они не чистились вообще и копились вечно (аудит остатков 2026-09-23).
#: `data.sqlite` (живая БД) под маски не попадает и не удаляется никогда.
_CLEANUP_GLOBS = (
    "data_*.sqlite",
    "data*.sqlite.before*",
    "data-before-*.sqlite",
    "pre_migration_*.sqlite",
)


def _cleanup(backup_dir: Path, keep_days: int) -> None:
    import time
    cutoff = time.time() - keep_days * 86400
    seen: set[Path] = set()
    for pattern in _CLEANUP_GLOBS:
        for f in backup_dir.glob(pattern):
            if f in seen or not f.is_file():
                continue
            seen.add(f)
            if f.stat().st_mtime < cutoff:
                f.unlink(missing_ok=True)
                logger.info("Removed old backup %s", f)


def verify_backup(path: str | Path) -> dict[str, str | bool]:
    """Verify a SQLite backup without mutating it."""
    p = Path(path)
    result: dict[str, str | bool] = {"path": str(p), "exists": p.is_file(), "ok": False}
    if not p.is_file():
        return result
    try:
        with closing(sqlite3.connect(p)) as con:
            check = str(con.execute("PRAGMA quick_check").fetchone()[0])
        result["quick_check"] = check
        result["ok"] = check.lower() == "ok"
    except Exception as exc:
        result["quick_check"] = f"error:{exc}"
    return result
