from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from .clock import Clock
from .config import AppConfig
from .db import Database

logger = logging.getLogger(__name__)
from .telegram_transport import HTML_PREFIX  # noqa: E402  (split_text — для тестов)


class TelegramNotifier:
    """Abstract notifier + command router. Real transport plugged later."""

    def __init__(self, cfg: AppConfig, db: Database, clock: Clock):
        self.cfg = cfg
        self.db = db
        self.clock = clock
        self._owner_chat_id: int | None = None
        self._handlers: dict[str, Callable] = {}
        self._pending_dialogs: dict[int, dict[str, Any]] = {}
        self.transport = None

    def is_allowed(self, chat_id: int) -> bool:
        allowed = self.cfg.telegram.allowed_chat_ids
        if not allowed:
            if self._owner_chat_id is None:
                self._owner_chat_id = chat_id
                return True
            return chat_id == self._owner_chat_id
        return chat_id in allowed

    def send(self, chat_id: int, text: str, reply_markup: dict | None = None) -> None:
        if not self.is_allowed(chat_id):
            logger.warning("Blocked message to unauthorized chat %s", chat_id)
            return
        if self.transport:
            self.transport.send_message(chat_id, text, reply_markup)
        else:
            logger.info("[TG -> %s] %s", chat_id, (text or "")[:200])

    def broadcast(self, text: str) -> None:
        targets = self.cfg.telegram.allowed_chat_ids or (
            [self._owner_chat_id] if self._owner_chat_id else []
        )
        for cid in targets:
            if cid:
                self.send(cid, text)

    def register(self, command: str, handler: Callable) -> None:
        self._handlers[command.lstrip("/")] = handler

    def handle_update(self, chat_id: int, text: str) -> str | None:
        if not self.is_allowed(chat_id):
            return "Access denied"

        text = (text or "").strip()
        if chat_id in self._pending_dialogs:
            return self._resolve_dialog(chat_id, text)

        if not text.startswith("/"):
            return ("🤖 Автоответ: сообщение дошло до бота. Когда я его прочитаю и отвечу, "
                    "на нём появится 👍. Команды: /help")
        parts = text.split(maxsplit=1)
        cmd = parts[0].lstrip("/").split("@")[0]
        arg = parts[1] if len(parts) > 1 else ""
        handler = self._handlers.get(cmd)
        if not handler:
            return f"Неизвестная команда: /{cmd}. Список: /help"
        return handler(chat_id, arg)

    def ask_series_end(self, platform: str, account_id: str = "") -> None:
        """P0.11: спросить про soft-end и зарегистрировать диалог (иначе ответ не резолвится)."""
        from datetime import timedelta

        ttl_days = int(getattr(self.cfg.tail, "series_end_question_ttl_days", 3) or 3)
        expires = (self.clock.now() + timedelta(days=ttl_days)).timestamp()
        targets = list(self.cfg.telegram.allowed_chat_ids or [])
        if not targets and self._owner_chat_id:
            targets = [self._owner_chat_id]
        for cid in targets:
            if cid:
                self._pending_dialogs[cid] = {
                    "type": "series_end", "platform": platform, "account_id": account_id or "", "expires": expires,
                }
        self.broadcast(
            f"Series soft-end on {platform}. Enter tail mode? Reply: yes / no"
        )

    def ask_missing_url(self, entity_id: int, platform: str, chat_id: int | None = None, account_id: str = "") -> None:
        dialog = {
            "type": "missing_url",
            "entity_id": entity_id,
            "platform": platform,
            "account_id": account_id or "",
            "expires": self.clock.now().timestamp()
            + self.cfg.link_update.missing_url_dialog_ttl_hours * 3600,
        }
        targets = [chat_id] if chat_id else (
            self.cfg.telegram.allowed_chat_ids
            or ([self._owner_chat_id] if self._owner_chat_id else [])
        )
        for cid in targets:
            if cid:
                self._pending_dialogs[cid] = dialog
                self.send(
                    cid,
                    f"No release_url for long_video #{entity_id} on {platform}.\n"
                    f"Send URL or 'skip' (default: {self.cfg.link_update.missing_url_default_action})",
                )

    def _resolve_dialog(self, chat_id: int, text: str) -> str:
        dlg = self._pending_dialogs.get(chat_id)
        if not dlg:
            return "No pending dialog"
        if self.clock.now().timestamp() > dlg["expires"]:
            del self._pending_dialogs[chat_id]
            return "Dialog expired"
        if dlg["type"] == "missing_url":
            return self._handle_missing_url(chat_id, dlg, text)
        if dlg["type"] == "series_end":
            return self._handle_series_end(chat_id, dlg, text)
        return "Unknown dialog"

    def _handle_missing_url(self, chat_id: int, dlg: dict, text: str) -> str:
        del self._pending_dialogs[chat_id]
        platform = dlg["platform"]
        eid = dlg["entity_id"]
        account_id = str(dlg.get("account_id") or "")
        if text.lower() in ("skip", "без ссылки", "no"):
            self.db.execute(
                "UPDATE entity_platform_status SET release_url=NULL, link_updated_at=? "
                "WHERE entity_type='long_video' AND entity_id=? AND platform=? AND account_id=?",
                (self.clock.now().isoformat(), eid, platform, account_id),
            )
            return f"Will post without link (video #{eid} / {platform})"
        if text.startswith("http://") or text.startswith("https://"):
            self.db.execute(
                "UPDATE entity_platform_status SET release_url=?, link_updated_at=? "
                "WHERE entity_type='long_video' AND entity_id=? AND platform=? AND account_id=?",
                (text.strip(), self.clock.now().isoformat(), eid, platform, account_id),
            )
            return f"URL saved for video #{eid} / {platform}"
        return "Send valid http(s) URL or 'skip'"

    def _handle_series_end(self, chat_id: int, dlg: dict, text: str) -> str:
        del self._pending_dialogs[chat_id]
        platform = dlg["platform"]
        account_id = str(dlg.get("account_id") or "").strip()
        aid = account_id
        if text.lower() in ("yes", "да", "y"):
            if aid:
                self.db.execute(
                    "INSERT INTO platform_queue_account_state("
                    "platform,account_id,series_tail_mode,pending_series_end_question,pending_series_end_at,updated_at) "
                    "VALUES(?,?,1,0,NULL,?) "
                    "ON CONFLICT(platform,account_id) DO UPDATE SET "
                    "series_tail_mode=1,pending_series_end_question=0,pending_series_end_at=NULL,updated_at=excluded.updated_at",
                    (platform, aid, self.clock.now().isoformat()),
                )
            else:
                self.db.execute(
                    "UPDATE platform_queue_state SET series_tail_mode=1, "
                    "pending_series_end_question=0, pending_series_end_at=NULL, updated_at=? "
                    "WHERE platform=?",
                    (self.clock.now().isoformat(), platform),
                )
            return f"Tail mode ON for {platform}"
        if aid:
            self.db.execute(
                "INSERT INTO platform_queue_account_state("
                "platform,account_id,series_tail_mode,pending_series_end_question,updated_at) "
                "VALUES(?,?,0,0,?) "
                "ON CONFLICT(platform,account_id) DO UPDATE SET "
                "series_tail_mode=0,pending_series_end_question=0,updated_at=excluded.updated_at",
                (platform, aid, self.clock.now().isoformat()),
            )
        else:
            self.db.execute(
                "UPDATE platform_queue_state SET series_tail_mode=0, pending_series_end_question=0, "
                "updated_at=? WHERE platform=?",
                (self.clock.now().isoformat(), platform),
            )
        return f"Tail mode OFF for {platform}"


    def broadcast_markup(self, text: str, reply_markup: dict) -> None:
        """P0.12/N1: рассылка с inline-кнопками всем allowed чатам (метод класса)."""
        targets = list(self.cfg.telegram.allowed_chat_ids or [])
        if not targets and self._owner_chat_id:
            targets = [self._owner_chat_id]
        for cid in targets:
            if cid:
                self.send(cid, text, reply_markup)

    def _backlog_markup(self, platform: str, account_id: str = "") -> dict:
        suffix = f" {account_id}" if account_id else ""
        return {"inline_keyboard": [[
            {"text": "Распределить остаток", "callback_data": f"backlog_distribute {platform}{suffix}"},
            {"text": "Ждать ещё", "callback_data": f"backlog_wait {platform}{suffix}"},
            {"text": "Не публиковать", "callback_data": f"backlog_skip {platform}{suffix}"},
        ]]}

    def ask_backlog(self, platform: str, count: int, account_id: str = "") -> None:
        scope = f" [{account_id}]" if account_id else ""
        text = (f"Серия закончилась? Не опубликовано шортсов: {count} ({platform}){scope}.\n"
                f"Если не ответить до слота — распределю остаток автоматически.")
        self.broadcast_markup(text, self._backlog_markup(platform, account_id))

    def remind_backlog(self, platform: str, count: int, account_id: str = "") -> None:
        scope = f" [{account_id}]" if account_id else ""
        text = (f"⚠️ ВАЖНО: серия закончилась, остаток {count} шортсов ({platform}){scope} "
                f"не распределён. Отвечай!")
        self.broadcast_markup(text, self._backlog_markup(platform, account_id))

    def backlog_distributed(self, platform: str, n: int) -> None:
        self.broadcast(f"Остаток распределён ({platform}): {n} шортсов поставлено в план.")


    def ask_claims(self, entity_type: str, entity_id: int, external_id: str, account_id: str = "") -> None:
        """Notify about possible Content ID claim; A3 buttons."""
        text = (
            f"⚠️ Возможный claim на YouTube\n"
            f"{entity_type}#{entity_id} id={external_id}\n"
            f"A3: удалить копию на платформе и взять следующее видео?"
        )
        markup = {"inline_keyboard": [[
            {"text": "A3: удалить + next", "callback_data": f"claims_a3 {entity_type} {entity_id} youtube {account_id}"},
            {"text": "Оставить", "callback_data": f"claims_keep {entity_type} {entity_id} youtube {account_id}"},
        ]]}
        self.broadcast_markup(text, markup)


def setup_commands(bot: TelegramNotifier, components: dict) -> None:
    db: Database = components["db"]
    cfg: AppConfig = components["cfg"]
    safety = components["safety"]
    scheduler = components["scheduler"]
    clock: Clock = components["clock"]

    def cmd_status(chat_id: int, arg: str) -> str:
        rows = db.fetchall(
            "SELECT platform, status, COUNT(*) AS cnt FROM entity_platform_status GROUP BY platform, status"
        )
        if not rows:
            return "No entities"
        lines = [f"{r['platform']} {r['status']}: {r['cnt']}" for r in rows]
        return "Status:\n" + "\n".join(lines)

    def cmd_pause(chat_id: int, arg: str) -> str:
        for p in cfg.platforms:
            safety.pause_platform(p, "manual")
        return "All platforms paused"

    def cmd_resume(chat_id: int, arg: str) -> str:
        for p in cfg.platforms:
            safety.resume_platform(p)
        return "All platforms resumed"

    def cmd_resume_platform(chat_id: int, arg: str) -> str:
        p = arg.strip().lower()
        if p not in cfg.platforms:
            return f"Unknown platform: {p}"
        safety.resume_platform(p)
        return f"Resumed {p}"

    WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]

    def _upcoming_rows(limit: int = 30) -> list[dict]:
        return db.fetchall(
            """
            SELECT eps.entity_type, eps.entity_id, eps.platform, eps.status,
                   eps.scheduled_for AS scheduled_for,
                   COALESCE(lv.title_text, lv.title, sh.title_text) AS title
            FROM entity_platform_status eps
            LEFT JOIN long_videos lv
                   ON eps.entity_type='long_video' AND lv.id = eps.entity_id
            LEFT JOIN shorts sh
                   ON eps.entity_type='short' AND sh.id = eps.entity_id
            WHERE eps.status IN ('ready', 'scheduled')
              AND eps.scheduled_for IS NOT NULL
            ORDER BY eps.scheduled_for LIMIT ?
            """,
            (limit,),
        )

    PLATFORM_ICONS = {
        "youtube": "▶️", "telegram": "✈️", "instagram": "📸",
        "tiktok": "🎵", "facebook": "📘", "vk": "🅥",
    }
    MONTHS_GEN = ["января", "февраля", "марта", "апреля", "мая", "июня",
                  "июля", "августа", "сентября", "октября", "ноября", "декабря"]

    def _item_lines(limit: int = 30, max_groups: int = 30) -> str:
        """Строки очереди: дни разделены, у платформ цветовые маркеры (HTML-разметка)."""
        import html as _html
        rows = _upcoming_rows(limit)
        grouped: dict[tuple, dict] = {}
        for r in rows:
            dt = None
            try:
                from datetime import UTC, datetime
                from zoneinfo import ZoneInfo
                dt = datetime.fromisoformat(str(r["scheduled_for"]).replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=UTC)
                dt = dt.astimezone(ZoneInfo(cfg.timezone))
            except Exception:
                dt = None
            day = f"{WEEKDAYS[dt.weekday()]}, {dt.day} {MONTHS_GEN[dt.month - 1]}" if dt else "—"
            hhmm = dt.strftime("%H:%M") if dt else str(r["scheduled_for"] or "")[:16]
            key = (r["entity_type"], r["entity_id"], day, hhmm)
            kind = "Фильм" if r["entity_type"] == "long_video" else "Шортс"
            title = (r.get("title") or "").strip() or f"#{r['entity_id']}"
            g = grouped.setdefault(key, {"day": day, "time": hhmm,
                                         "label": f"{kind}: {title}", "plats": []})
            g["plats"].append(r["platform"])
        lines: list[str] = []
        last_day = None
        shown = 0
        for g in grouped.values():
            if shown >= max_groups:
                break
            if g["day"] != last_day:
                if last_day is not None:
                    lines.append("")
                lines.append(f"📅 <b>{g['day']}</b>")
                last_day = g["day"]
            marks = " ".join(
                f"{PLATFORM_ICONS.get(p, '▪️')}" for p in dict.fromkeys(g["plats"])
            )
            lines.append(f"{marks} <code>{g['time']}</code> · {_html.escape(g['label'])}")
            shown += 1
        return "\n".join(lines)

    def cmd_queue(chat_id: int, arg: str) -> str:
        body = _item_lines(limit=30, max_groups=17)
        if not body:
            return "Очередь пуста."
        return HTML_PREFIX + "Очередь публикаций:\n\n" + body

    def cmd_failed(chat_id: int, arg: str) -> str:
        rows = db.fetchall(
            """
            SELECT eps.entity_type, eps.entity_id, eps.platform, eps.last_error,
                   COALESCE(lv.title_text, lv.title, sh.title_text) AS title
            FROM entity_platform_status eps
            LEFT JOIN long_videos lv
                   ON eps.entity_type='long_video' AND lv.id = eps.entity_id
            LEFT JOIN shorts sh
                   ON eps.entity_type='short' AND sh.id = eps.entity_id
            WHERE eps.status IN ('failed','error') LIMIT 20
            """
        )
        if not rows:
            return "Ошибок нет."
        out = ["Ошибки публикаций:"]
        for r in rows:
            kind = "Фильм" if r["entity_type"] == "long_video" else "Шортс"
            title = (r.get("title") or "").strip() or f"#{r['entity_id']}"
            out.append(f"{kind}: {title} · {r['platform']} · {r['last_error'] or '—'}")
        return "\n".join(out)

    def cmd_tail(chat_id: int, arg: str) -> str:
        rows = db.fetchall(
            "SELECT platform, series_tail_mode FROM platform_queue_state"
        )
        return "\n".join(
            f"{r['platform']}: tail={'ON' if r['series_tail_mode'] else 'OFF'}" for r in rows
        )

    def cmd_platforms(chat_id: int, arg: str) -> str:
        lines = []
        for name, p in cfg.platforms.items():
            st = db.fetchone(
                "SELECT is_paused, pause_reason FROM platform_safety_state WHERE platform=?",
                (name,),
            )
            paused = "PAUSED" if st and st["is_paused"] else "ok"
            lines.append(f"{name}: enabled={p.enabled} limit={p.daily_limit} {paused}")
        return "\n".join(lines)

    def cmd_distribute(chat_id: int, arg: str) -> str:
        _w = components.get("watcher")
        _roots = [str(r) for r in _w.effective_roots()] if _w is not None else []
        n = scheduler.schedule_long_videos(scope_roots=_roots)
        return f"Distributed long videos: {n}"

    def cmd_calendar(chat_id: int, arg: str) -> str:
        body = _item_lines(limit=60, max_groups=30)
        if not body:
            return "Календарь пуст."
        return HTML_PREFIX + "Ближайшие публикации:\n\n" + body

    def cmd_series_end(chat_id: int, arg: str) -> str:
        parts = arg.strip().split()
        p = parts[0].lower() if parts else "youtube"
        aid = parts[1] if len(parts) > 1 else ""
        if components.get("backlog") is not None:
            try:
                aid = components["backlog"]._account_id(p, aid)
            except ValueError:
                return f"Для /series_end при нескольких аккаунтах укажите account_id: /series_end {p} <account_id>"
        bot._pending_dialogs[chat_id] = {
            "type": "series_end",
            "platform": p,
            "account_id": aid,
            "expires": clock.now().timestamp() + 86400,
        }
        return f"Enter tail mode for {p} [{aid or '-'}]? yes / no"

    def cmd_force_link_update(chat_id: int, arg: str) -> str:
        parts = arg.split()
        if len(parts) < 3:
            return "Usage: /force_link_update <entity_id> <platform> <url> [short|long_video]"
        eid, platform, url = int(parts[0]), parts[1], parts[2]
        etype = parts[3] if len(parts) > 3 else None
        link_upd = components.get("link_upd")
        if not link_upd:
            return "LinkUpdater not available"
        ok = link_upd.force_update(
            eid, platform, url,
            scheduler=components.get('scheduler'), entity_type=etype)
        return "OK" if ok else "Failed"

    def cmd_reload_config(chat_id: int, arg: str) -> str:
        from .reload import apply_config_to_comps, reload_config
        path = arg.strip() or "config.yaml"
        new_cfg, msg = reload_config(path, cfg)
        if new_cfg is None:
            return f"Reload failed (kept old): {msg}"
        updated = apply_config_to_comps(components, new_cfg)
        return f"Config reloaded → {', '.join(updated)}; restart if bind/TLS changed"

    def cmd_next_video(chat_id: int, arg: str) -> str:
        platform = arg.strip() or None
        sql = (
            "SELECT entity_id, platform, "
            "scheduled_for AS scheduled_for "
            "FROM entity_platform_status "
            "WHERE entity_type='long_video' AND status='scheduled' "
        )
        params: tuple = ()
        if platform:
            sql += "AND platform=? "
            params = (platform,)
        sql += "ORDER BY scheduled_for LIMIT 5"
        rows = db.fetchall(sql, params)
        if not rows:
            return "No scheduled long videos"
        return "\n".join(
            f"#{r['entity_id']} {r['platform']} {r['scheduled_for']}" for r in rows
        )

    def cmd_next_short(chat_id: int, arg: str) -> str:
        platform = arg.strip() or None
        sql = (
            "SELECT entity_id, platform, "
            "scheduled_for AS scheduled_for "
            "FROM entity_platform_status "
            "WHERE entity_type='short' AND status='scheduled' "
        )
        params: tuple = ()
        if platform:
            sql += "AND platform=? "
            params = (platform,)
        sql += "ORDER BY scheduled_for LIMIT 5"
        rows = db.fetchall(sql, params)
        if not rows:
            return "No scheduled shorts"
        return "\n".join(
            f"#{r['entity_id']} {r['platform']} {r['scheduled_for']}" for r in rows
        )



    def broadcast_markup(self, text: str, reply_markup: dict) -> None:
        targets = self.cfg.telegram.allowed_chat_ids or (
            [self._owner_chat_id] if self._owner_chat_id else []
        )
        for cid in targets:
            if not cid:
                continue
            if not self.is_allowed(cid):
                continue
            if self.transport:
                self.transport.send_message(cid, text, reply_markup)
            else:
                logger.info("[TG-markup -> %s] %s", cid, text[:200])

    def cmd_app(chat_id: int, arg: str) -> str:
        import os
        url = os.getenv("WEBAPP_PUBLIC_URL", "").rstrip("/")
        if not url:
            return "Задайте WEBAPP_PUBLIC_URL (например https://host/webapp/)"
        # Client apps open via menu button; here we return the link
        return f"Откройте панель:\n{url}/\n\n(В BotFather: Menu Button → Web App → этот URL)"

    def _backlog_target(m, arg: str) -> tuple[str, str, str | None]:
        parts = (arg or "").strip().split()
        p = parts[0].lower() if parts else next(iter(cfg.platforms), "")
        requested = parts[1] if len(parts) > 1 else ""
        try:
            aid = m._account_id(p, requested)
        except ValueError:
            return p, requested, "account_id_required"
        return p, aid, None

    def cmd_backlog_distribute(chat_id: int, arg: str) -> str:
        m = components.get("backlog")
        if not m:
            return "Менеджер остатка недоступен"
        p, aid, err = _backlog_target(m, arg)
        if err:
            return f"Для /backlog_distribute при нескольких аккаунтах укажите account_id: /backlog_distribute {p} <account_id>"
        n = m.resolve(p, "distribute", account_id=aid)
        return f"Остаток распределён ({p}) [{aid or '-'}]: {n}"

    def cmd_backlog_wait(chat_id: int, arg: str) -> str:
        m = components.get("backlog")
        if not m:
            return "Менеджер остатка недоступен"
        p, aid, err = _backlog_target(m, arg)
        if err:
            return f"Для /backlog_wait при нескольких аккаунтах укажите account_id: /backlog_wait {p} <account_id>"
        m.resolve(p, "wait", account_id=aid)
        return f"Ждём новую серию ({p}) [{aid or '-'}]."

    def cmd_backlog_skip(chat_id: int, arg: str) -> str:
        m = components.get("backlog")
        if not m:
            return "Менеджер остатка недоступен"
        p, aid, err = _backlog_target(m, arg)
        if err:
            return f"Для /backlog_skip при нескольких аккаунтах укажите account_id: /backlog_skip {p} <account_id>"
        m.resolve(p, "skip", account_id=aid)
        return f"Остаток не публикуем ({p}) [{aid or '-'}]."


    def _claim_account_id(entity_type: str, entity_id: int, platform: str, requested: str = "") -> tuple[str | None, str | None]:
        requested = str(requested or "").strip()
        if requested:
            row = db.fetchone(
                "SELECT account_id FROM entity_platform_status WHERE entity_type=? AND entity_id=? AND platform=? AND account_id=?",
                (entity_type, entity_id, platform, requested),
            )
            return (requested, None) if row is not None else (None, "account_not_found")
        rows = db.fetchall(
            "SELECT DISTINCT account_id FROM entity_platform_status WHERE entity_type=? AND entity_id=? AND platform=?",
            (entity_type, entity_id, platform),
        )
        accounts = [str(r.get("account_id") or "") for r in (rows or [])]
        accounts = list(dict.fromkeys(accounts))
        if len(accounts) == 1:
            return accounts[0], None
        if len(accounts) > 1:
            return None, "account_id_required"
        return None, "account_not_found"

    def cmd_claims_a3(chat_id: int, arg: str) -> str:
        parts = (arg or "").split()
        if len(parts) < 2:
            return "usage: claims_a3 TYPE ID [platform] [account_id]"
        et, eid = parts[0], parts[1]
        plat = parts[2] if len(parts) > 2 and parts[2] else "youtube"
        requested_account = parts[3] if len(parts) > 3 else ""
        try:
            eid_i = int(eid)
        except ValueError:
            return "bad entity_id"
        account_id, err = _claim_account_id(et, eid_i, plat, requested_account)
        if err == "account_id_required":
            return "claims A3 requires account_id when multiple accounts exist"
        if err:
            return "claim target account not found"
        from .claims import resolve_claim_a3
        try:
            resolve_claim_a3(db, et, eid_i, plat, account_id=account_id or "")
        except Exception as e:
            return f"claims A3 failed: {e}"
        return f"A3 applied for {et}#{eid} on {plat} [{account_id or '-'}]"

    def cmd_claims_keep(chat_id: int, arg: str) -> str:
        parts = (arg or "").split()
        if len(parts) < 2:
            return "usage: claims_keep TYPE ID [platform] [account_id]"
        et, eid = parts[0], parts[1]
        plat = parts[2] if len(parts) > 2 and parts[2] else "youtube"
        requested_account = parts[3] if len(parts) > 3 else ""
        try:
            eid_i = int(eid)
        except ValueError:
            return "bad entity_id"
        account_id, err = _claim_account_id(et, eid_i, plat, requested_account)
        if err == "account_id_required":
            return "claims keep requires account_id when multiple accounts exist"
        if err:
            return "claim target account not found"
        db.execute(
            "UPDATE entity_platform_status SET claims_state='kept' "
            "WHERE entity_type=? AND entity_id=? AND platform=? AND account_id=?",
            (et, eid_i, plat, account_id or ""),
        )
        return f"claim kept for {et}#{eid} on {plat} [{account_id or '-'}]"

    def cmd_help(chat_id: int, arg: str) -> str:
        return (
            "Команды:\n"
            "/app — открыть панель\n"
            "/status — статус и счётчики\n"
            "/queue — очередь публикаций\n"
            "/calendar — календарь\n"
            "/failed — ошибки публикаций\n"
            "/platforms — платформы и лимиты\n"
            "/pause, /resume — пауза / возобновить всё\n"
            "/distribute — разложить по слотам\n"
            "/tail — остаток шортсов серии\n"
            "/claims_a3 TYPE ID [platform] [account_id] — A3 delete+next (claim)\n"
            "/claims_keep TYPE ID [platform] [account_id] — оставить при claim"
        )

    bot.register("claims_a3", cmd_claims_a3)
    bot.register("claims_keep", cmd_claims_keep)
    bot.register("help", cmd_help)
    bot.register("backlog_distribute", cmd_backlog_distribute)
    bot.register("backlog_wait", cmd_backlog_wait)
    bot.register("backlog_skip", cmd_backlog_skip)
    bot.register("app", cmd_app)
    bot.register("status", cmd_status)
    bot.register("pause", cmd_pause)
    bot.register("resume", cmd_resume)
    bot.register("resume_platform", cmd_resume_platform)
    bot.register("queue", cmd_queue)
    bot.register("failed", cmd_failed)
    bot.register("tail", cmd_tail)
    bot.register("platforms", cmd_platforms)
    bot.register("distribute", cmd_distribute)
    bot.register("calendar", cmd_calendar)
    bot.register("series_end", cmd_series_end)
    bot.register("force_link_update", cmd_force_link_update)
    bot.register("reload_config", cmd_reload_config)
    bot.register("next_video", cmd_next_video)
    bot.register("next_short", cmd_next_short)
