# R3 approval and live-canary record
Provider:
Approved product/capability:
Approved scopes:
Approval reference/ticket:
Approved app/client ID:
Approved redirect URIs:
Production destination/account:
Build fingerprint:

Canary:
- [ ] One approved live account added.
- [ ] Exactly one live operation executed.
- [ ] Provider resource/result verified.
- [ ] Status reconciliation verified.
- [ ] Logging/quota/error handling verified.
- [ ] Rollback path verified.
- [ ] Only after the above: scheduled automation explicitly enabled.

Canary timestamp:
Canary resource/object ID:
Operator:
Rollback result:
